﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FashionShopApp.Model
{
    public class LoaiSanPhamCha
    {
        public int IdLoaiSPCha { get; set; }
        public string TenLoaiSPCha { get; set; }
    }
}
