﻿namespace FashionShopApp.GUI
{
    partial class frmKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKhachHang));
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_gioitinh = new System.Windows.Forms.TextBox();
            this.txt_diachi = new System.Windows.Forms.TextBox();
            this.txt_IdKH = new System.Windows.Forms.TextBox();
            this.txt_sdt = new System.Windows.Forms.TextBox();
            this.txt_TenKH = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lvGiaoDich = new System.Windows.Forms.ListView();
            this.MaHD = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NgayXuatHD = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TongTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dgv = new System.Windows.Forms.DataGridView();
            this.label16 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_ngaysinh = new System.Windows.Forms.TextBox();
            this.txt_IdAcc = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn_FindGD = new System.Windows.Forms.Button();
            this.btn_ResetTextBox = new System.Windows.Forms.Button();
            this.btn_ThemKH = new System.Windows.Forms.Button();
            this.btn_XoaKH = new System.Windows.Forms.Button();
            this.btn_CapNhatKH = new System.Windows.Forms.Button();
            this.btn_Luu = new System.Windows.Forms.Button();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_mail
            // 
            resources.ApplyResources(this.txt_mail, "txt_mail");
            this.txt_mail.Name = "txt_mail";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label2.Name = "label2";
            // 
            // txt_gioitinh
            // 
            resources.ApplyResources(this.txt_gioitinh, "txt_gioitinh");
            this.txt_gioitinh.Name = "txt_gioitinh";
            // 
            // txt_diachi
            // 
            resources.ApplyResources(this.txt_diachi, "txt_diachi");
            this.txt_diachi.Name = "txt_diachi";
            // 
            // txt_IdKH
            // 
            resources.ApplyResources(this.txt_IdKH, "txt_IdKH");
            this.txt_IdKH.Name = "txt_IdKH";
            // 
            // txt_sdt
            // 
            resources.ApplyResources(this.txt_sdt, "txt_sdt");
            this.txt_sdt.Name = "txt_sdt";
            // 
            // txt_TenKH
            // 
            resources.ApplyResources(this.txt_TenKH, "txt_TenKH");
            this.txt_TenKH.Name = "txt_TenKH";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label15.Name = "label15";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label14.Name = "label14";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label13.Name = "label13";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label12.Name = "label12";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label10.Name = "label10";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.lvGiaoDich);
            this.groupBox4.Controls.Add(this.dgv);
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label4.Name = "label4";
            // 
            // lvGiaoDich
            // 
            this.lvGiaoDich.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.MaHD,
            this.NgayXuatHD,
            this.TongTien});
            this.lvGiaoDich.HideSelection = false;
            resources.ApplyResources(this.lvGiaoDich, "lvGiaoDich");
            this.lvGiaoDich.Name = "lvGiaoDich";
            this.lvGiaoDich.UseCompatibleStateImageBehavior = false;
            this.lvGiaoDich.View = System.Windows.Forms.View.Details;
            // 
            // MaHD
            // 
            resources.ApplyResources(this.MaHD, "MaHD");
            // 
            // NgayXuatHD
            // 
            resources.ApplyResources(this.NgayXuatHD, "NgayXuatHD");
            // 
            // TongTien
            // 
            resources.ApplyResources(this.TongTien, "TongTien");
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dgv, "dgv");
            this.dgv.Name = "dgv";
            this.dgv.RowTemplate.Height = 24;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            this.dgv.Click += new System.EventHandler(this.dgv_Click);
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.Name = "label16";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label1.Name = "label1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_FindGD);
            this.groupBox2.Controls.Add(this.txt_ngaysinh);
            this.groupBox2.Controls.Add(this.txt_IdAcc);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txt_mail);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txt_gioitinh);
            this.groupBox2.Controls.Add(this.txt_diachi);
            this.groupBox2.Controls.Add(this.txt_IdKH);
            this.groupBox2.Controls.Add(this.txt_sdt);
            this.groupBox2.Controls.Add(this.txt_TenKH);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.tableLayoutPanel1);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // txt_ngaysinh
            // 
            resources.ApplyResources(this.txt_ngaysinh, "txt_ngaysinh");
            this.txt_ngaysinh.Name = "txt_ngaysinh";
            // 
            // txt_IdAcc
            // 
            resources.ApplyResources(this.txt_IdAcc, "txt_IdAcc");
            this.txt_IdAcc.Name = "txt_IdAcc";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(54)))), ((int)(((byte)(137)))));
            this.label3.Name = "label3";
            // 
            // tableLayoutPanel1
            // 
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.btn_ResetTextBox, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_ThemKH, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_XoaKH, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_CapNhatKH, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_Luu, 4, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // btn_FindGD
            // 
            this.btn_FindGD.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_FindGD.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_FindGD, "btn_FindGD");
            this.btn_FindGD.Name = "btn_FindGD";
            this.btn_FindGD.UseVisualStyleBackColor = false;
            this.btn_FindGD.Click += new System.EventHandler(this.btn_FindGD_Click);
            // 
            // btn_ResetTextBox
            // 
            this.btn_ResetTextBox.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_ResetTextBox.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_ResetTextBox, "btn_ResetTextBox");
            this.btn_ResetTextBox.Name = "btn_ResetTextBox";
            this.btn_ResetTextBox.UseVisualStyleBackColor = false;
            this.btn_ResetTextBox.Click += new System.EventHandler(this.btn_ResetTextBox_Click);
            // 
            // btn_ThemKH
            // 
            this.btn_ThemKH.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_ThemKH.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_ThemKH, "btn_ThemKH");
            this.btn_ThemKH.Image = global::FashionShopApp.Properties.Resources.add;
            this.btn_ThemKH.Name = "btn_ThemKH";
            this.btn_ThemKH.UseVisualStyleBackColor = false;
            this.btn_ThemKH.Click += new System.EventHandler(this.btn_ThemKH_Click);
            // 
            // btn_XoaKH
            // 
            this.btn_XoaKH.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_XoaKH.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_XoaKH, "btn_XoaKH");
            this.btn_XoaKH.Image = global::FashionShopApp.Properties.Resources.delete;
            this.btn_XoaKH.Name = "btn_XoaKH";
            this.btn_XoaKH.UseVisualStyleBackColor = false;
            this.btn_XoaKH.Click += new System.EventHandler(this.btn_XoaKH_Click);
            // 
            // btn_CapNhatKH
            // 
            this.btn_CapNhatKH.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_CapNhatKH.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_CapNhatKH, "btn_CapNhatKH");
            this.btn_CapNhatKH.Image = global::FashionShopApp.Properties.Resources.updated;
            this.btn_CapNhatKH.Name = "btn_CapNhatKH";
            this.btn_CapNhatKH.UseVisualStyleBackColor = false;
            this.btn_CapNhatKH.Click += new System.EventHandler(this.btn_CapNhatKH_Click);
            // 
            // btn_Luu
            // 
            this.btn_Luu.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_Luu.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_Luu, "btn_Luu");
            this.btn_Luu.Image = global::FashionShopApp.Properties.Resources.icons8_save_30;
            this.btn_Luu.Name = "btn_Luu";
            this.btn_Luu.UseVisualStyleBackColor = false;
            this.btn_Luu.Click += new System.EventHandler(this.btn_Luu_Click);
            // 
            // frmKhachHang
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Name = "frmKhachHang";
            this.Load += new System.EventHandler(this.frmKhachHang_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_gioitinh;
        private System.Windows.Forms.TextBox txt_diachi;
        private System.Windows.Forms.TextBox txt_IdKH;
        private System.Windows.Forms.TextBox txt_sdt;
        private System.Windows.Forms.TextBox txt_TenKH;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox txt_IdAcc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_ngaysinh;
        private System.Windows.Forms.Button btn_FindGD;
        private System.Windows.Forms.ListView lvGiaoDich;
        private System.Windows.Forms.ColumnHeader MaHD;
        private System.Windows.Forms.ColumnHeader NgayXuatHD;
        private System.Windows.Forms.ColumnHeader TongTien;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btn_ResetTextBox;
        private System.Windows.Forms.Button btn_ThemKH;
        private System.Windows.Forms.Button btn_XoaKH;
        private System.Windows.Forms.Button btn_CapNhatKH;
        private System.Windows.Forms.Button btn_Luu;
    }
}