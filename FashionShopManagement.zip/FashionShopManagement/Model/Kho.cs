﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FashionShopApp.Model
{
    public class Kho
    {
        public int IdChiNhanh { get; set; }
        public long IdSanPham { get; set; }
        public int SoLuongTonKho { get; set; }
    }
}
