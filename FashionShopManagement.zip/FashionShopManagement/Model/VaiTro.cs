﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FashionShopApp.Model
{
    public class VaiTro
    {
        public int IdVaiTro { get; set; }
        public string TenVaiTro { get; set; }
    }
}
