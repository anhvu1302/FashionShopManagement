﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FashionShopApp.Model
{
    public class LoaiSanPham
    {
        public int IdLoaiSP { get; set; }
        public string TenLoaiSP { get; set; }
        public int IdLoaiSPCha { get; set; }
    }
}
