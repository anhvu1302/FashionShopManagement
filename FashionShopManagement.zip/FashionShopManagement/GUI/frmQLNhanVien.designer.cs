﻿namespace FashionShopApp.GUI
{
    partial class frmQLNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQLNhanVien));
            this.txt_IDNhanVien = new System.Windows.Forms.TextBox();
            this.txt_IDNguoiDung = new System.Windows.Forms.TextBox();
            this.txt_TenNhanVien = new System.Windows.Forms.TextBox();
            this.txt_NgaySinh = new System.Windows.Forms.TextBox();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.txt_SoDienThoai = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLuu = new System.Windows.Forms.Button();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_GioiTinh = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_XoaNV = new System.Windows.Forms.Button();
            this.btn_CapNhatNV = new System.Windows.Forms.Button();
            this.btn_ThemNV = new System.Windows.Forms.Button();
            this.btn_ResetNV = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_IDNhanVien
            // 
            resources.ApplyResources(this.txt_IDNhanVien, "txt_IDNhanVien");
            this.txt_IDNhanVien.Name = "txt_IDNhanVien";
            // 
            // txt_IDNguoiDung
            // 
            resources.ApplyResources(this.txt_IDNguoiDung, "txt_IDNguoiDung");
            this.txt_IDNguoiDung.Name = "txt_IDNguoiDung";
            // 
            // txt_TenNhanVien
            // 
            resources.ApplyResources(this.txt_TenNhanVien, "txt_TenNhanVien");
            this.txt_TenNhanVien.Name = "txt_TenNhanVien";
            // 
            // txt_NgaySinh
            // 
            resources.ApplyResources(this.txt_NgaySinh, "txt_NgaySinh");
            this.txt_NgaySinh.Name = "txt_NgaySinh";
            // 
            // txt_DiaChi
            // 
            resources.ApplyResources(this.txt_DiaChi, "txt_DiaChi");
            this.txt_DiaChi.Name = "txt_DiaChi";
            // 
            // textBox6
            // 
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.Name = "textBox6";
            // 
            // txt_SoDienThoai
            // 
            resources.ApplyResources(this.txt_SoDienThoai, "txt_SoDienThoai");
            this.txt_SoDienThoai.Name = "txt_SoDienThoai";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnLuu);
            this.groupBox1.Controls.Add(this.txt_Email);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_GioiTinh);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btn_XoaNV);
            this.groupBox1.Controls.Add(this.btn_CapNhatNV);
            this.groupBox1.Controls.Add(this.btn_ThemNV);
            this.groupBox1.Controls.Add(this.btn_ResetNV);
            this.groupBox1.Controls.Add(this.txt_IDNhanVien);
            this.groupBox1.Controls.Add(this.txt_SoDienThoai);
            this.groupBox1.Controls.Add(this.txt_IDNguoiDung);
            this.groupBox1.Controls.Add(this.txt_TenNhanVien);
            this.groupBox1.Controls.Add(this.txt_DiaChi);
            this.groupBox1.Controls.Add(this.txt_NgaySinh);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // btnLuu
            // 
            this.btnLuu.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnLuu.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btnLuu, "btnLuu");
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.UseVisualStyleBackColor = false;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // txt_Email
            // 
            resources.ApplyResources(this.txt_Email, "txt_Email");
            this.txt_Email.Name = "txt_Email";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // txt_GioiTinh
            // 
            resources.ApplyResources(this.txt_GioiTinh, "txt_GioiTinh");
            this.txt_GioiTinh.Name = "txt_GioiTinh";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // btn_XoaNV
            // 
            this.btn_XoaNV.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_XoaNV.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_XoaNV, "btn_XoaNV");
            this.btn_XoaNV.Image = global::FashionShopApp.Properties.Resources.delete;
            this.btn_XoaNV.Name = "btn_XoaNV";
            this.btn_XoaNV.UseVisualStyleBackColor = false;
            this.btn_XoaNV.Click += new System.EventHandler(this.btn_XoaNV_Click);
            // 
            // btn_CapNhatNV
            // 
            this.btn_CapNhatNV.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_CapNhatNV.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_CapNhatNV, "btn_CapNhatNV");
            this.btn_CapNhatNV.Image = global::FashionShopApp.Properties.Resources.updated;
            this.btn_CapNhatNV.Name = "btn_CapNhatNV";
            this.btn_CapNhatNV.UseVisualStyleBackColor = false;
            this.btn_CapNhatNV.Click += new System.EventHandler(this.btn_CapNhatNV_Click);
            // 
            // btn_ThemNV
            // 
            this.btn_ThemNV.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_ThemNV.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_ThemNV, "btn_ThemNV");
            this.btn_ThemNV.Image = global::FashionShopApp.Properties.Resources.add;
            this.btn_ThemNV.Name = "btn_ThemNV";
            this.btn_ThemNV.UseVisualStyleBackColor = false;
            this.btn_ThemNV.Click += new System.EventHandler(this.btn_ThemNV_Click);
            // 
            // btn_ResetNV
            // 
            this.btn_ResetNV.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btn_ResetNV.FlatAppearance.BorderSize = 0;
            resources.ApplyResources(this.btn_ResetNV, "btn_ResetNV");
            this.btn_ResetNV.Name = "btn_ResetNV";
            this.btn_ResetNV.UseVisualStyleBackColor = false;
            this.btn_ResetNV.Click += new System.EventHandler(this.btn_ResetNV_Click);
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            resources.ApplyResources(this.dgv, "dgv");
            this.dgv.Name = "dgv";
            this.dgv.RowTemplate.Height = 24;
            this.dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellClick);
            // 
            // frmQLNhanVien
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ControlBox = false;
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox6);
            this.Name = "frmQLNhanVien";
            this.Load += new System.EventHandler(this.frmQLNhanVien_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_IDNhanVien;
        private System.Windows.Forms.TextBox txt_IDNguoiDung;
        private System.Windows.Forms.TextBox txt_TenNhanVien;
        private System.Windows.Forms.TextBox txt_NgaySinh;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox txt_SoDienThoai;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_ResetNV;
        private System.Windows.Forms.Button btn_ThemNV;
        private System.Windows.Forms.Button btn_CapNhatNV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_XoaNV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_GioiTinh;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.Button btnLuu;
    }
}